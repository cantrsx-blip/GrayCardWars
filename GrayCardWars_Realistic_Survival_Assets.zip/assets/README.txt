GRAY CARD WARS — Realistic Survival Asset Pack
Original procedural GLB/PBR pack for Godot 4.5 / Android.
Scale: 1 unit = 1 meter. Y-up. Origins at ground contact unless noted.
NOT photogrammetry / not copied from Oxide or other games.
Geometry is original low/mid-poly, textures are original procedural PBR.

IMPORT (Godot 4.5):
  Copy assets/ into res://assets/
  Advanced import: generate tangents, +Y up.
  Building kit snaps on a 3.0 m grid.
  Campfire flame: GPUParticles3D at local (0, 0.35, 0).
  Characters are static meshes — add Skeleton3D/AnimationPlayer yourself.
  Plants use alpha billboards; set transparency alpha scissor on Android.
  Ground: assign albedo/normal/roughness/ao from environment/ground.
  Water: textures/water_normal.png + water_foam.png in a cheap scrolling shader.

LOD: *_lod1.glb / *_lod2.glb for trees and rocks. Use VisibilityNotifier / LOD.
Collision: *_col.glb simple hulls. Do not use visual mesh as collider.

FILE                                                   FACES   VERTS  TEX     NOTE
--------------------------------------------------------------------------------------------------------------
environment/rocks/rock_pebble_01.glb                      80      42  1024 rock scatter rock
environment/rocks/rock_pebble_02.glb                      80      42  1024 rock scatter rock
environment/rocks/rock_small_01.glb                       80      42  1024 rock scatter rock
environment/rocks/rock_small_02.glb                       80      42  1024 rock scatter rock
environment/rocks/rock_small_03.glb                       80      42  1024 rock scatter rock
environment/rocks/rock_medium_01.glb                      80      42  1024 rock scatter rock
environment/rocks/rock_medium_02.glb                      80      42  1024 rock scatter rock
environment/rocks/rock_medium_03.glb                     320     162  1024 rock scatter rock
environment/rocks/rock_large_01.glb                      320     162  1024 rock scatter rock
environment/rocks/rock_large_02.glb                      320     162  1024 rock scatter rock
environment/rocks/rock_boulder_01.glb                    320     162  1024 rock scatter rock
environment/rocks/rock_flat_01.glb                        80      42  1024 rock scatter rock
environment/rocks/rock_sharp_01.glb                       80      42  1024 rock scatter rock
environment/rocks/rock_cliff_chunk_01.glb                320     162  1024 rock scatter rock
environment/rocks/rock_cliff_chunk_02.glb                320     162  1024 rock scatter rock
environment/trees/tree_pine_01.glb                       652     362  1024 bark tree
environment/trees/tree_pine_02.glb                       652     362  1024 bark tree
environment/trees/tree_pine_03.glb                       552     308  1024 bark tree
environment/trees/tree_oak_01.glb                        656     356  1024 bark tree
environment/trees/tree_oak_old_01.glb                    656     356  1024 bark tree
environment/trees/tree_old_giant_01.glb                  756     410  1024 bark tree
environment/trees/tree_young_01.glb                      356     194  1024 bark tree
environment/trees/tree_young_02.glb                      356     194  1024 bark tree
environment/trees/tree_dead_01.glb                       156      92  1024 bark tree
environment/trees/tree_dead_02.glb                       136      80  1024 bark tree
environment/trees/tree_broadleaf_01.glb                  656     356  1024 bark tree
environment/trees/tree_twisted_01.glb                    556     302  1024 bark tree
environment/plants/plant_grass_01.glb                      4       8  512 alpha billboard plant
environment/plants/plant_grass_02.glb                      4       8  512 alpha billboard plant
environment/plants/plant_grass_03.glb                      4       8  512 alpha billboard plant
environment/plants/plant_dry_grass_01.glb                  4       8  512 alpha billboard plant
environment/plants/plant_dry_grass_02.glb                  4       8  512 alpha billboard plant
environment/plants/plant_bush_01.glb                       4       8  512 alpha billboard plant
environment/plants/plant_bush_02.glb                       4       8  512 alpha billboard plant
environment/plants/plant_weed_01.glb                       4       8  512 alpha billboard plant
environment/plants/plant_weed_02.glb                       4       8  512 alpha billboard plant
environment/plants/plant_shrub_01.glb                      4       8  512 alpha billboard plant
environment/plants/debris_log_01.glb                      32      18  1024 bark fallen log
environment/plants/debris_log_02.glb                      32      18  1024 bark fallen log
environment/plants/debris_branch_01.glb                   32      18  1024 bark fallen log
environment/plants/debris_stump_01.glb                    36      20  1024 bark stump
environment/coast/coast_pebble_01.glb                    320     162  1024 rock shore pebble
building/wood/foundation.glb                              12       8  1024 wood build piece foundation, 3m grid
building/wood/triangle_foundation.glb                      8       6  1024 wood build piece triangle_foundation, 3m grid
building/wood/wall.glb                                    12       8  1024 wood build piece wall, 3m grid
building/wood/doorway_wall.glb                            36      24  1024 wood build piece doorway_wall, 3m grid
building/wood/door.glb                                    12       8  1024 wood build piece door, 3m grid
building/wood/window_wall.glb                             48      32  1024 wood build piece window_wall, 3m grid
building/wood/window.glb                                  12       8  1024 wood build piece window, 3m grid
building/wood/half_wall.glb                               12       8  1024 wood build piece half_wall, 3m grid
building/wood/floor.glb                                   12       8  1024 wood build piece floor, 3m grid
building/wood/roof.glb                                    12       8  1024 wood build piece roof, 3m grid
building/wood/triangle_roof.glb                            4       4  1024 wood build piece triangle_roof, 3m grid
building/wood/stairs.glb                                 120      80  1024 wood build piece stairs, 3m grid
building/wood/ramp.glb                                     8       6  1024 wood build piece ramp, 3m grid
building/wood/pillar.glb                                  12       8  1024 wood build piece pillar, 3m grid
building/wood/fence.glb                                   48      32  1024 wood build piece fence, 3m grid
props/campfire/campfire.glb                             2168    1094  bark     flame pivot at local (0, 0.35, 0)
props/survival/workbench.glb                              60      40  wood     crafting table
props/survival/torch.glb                                 104      56  wood     flame pivot (0,0.72,0)
items/tools/stone_axe.glb                                 44      26  1024     grip at (0,0.1,0), blade +Y
items/tools/metal_axe.glb                                 44      26  1024     grip at (0,0.1,0)
items/tools/stone_pickaxe.glb                             44      26  1024     double head pick
items/tools/metal_pickaxe.glb                             44      26  1024     double head pick
items/tools/hammer.glb                                    44      26  1024     building hammer
items/tools/building_hammer.glb                           44      26  1024     construction hammer
items/weapons/scrap_sidearm.glb                           36      24  1024     original pipe-frame sidearm, grip origin
items/weapons/scrap_rifle.glb                             48      32  1024     original long scrap rifle
items/weapons/scrap_scattergun.glb                        48      32  1024     original dual-tube scattergun
vehicles/boat/wood_skiff.glb                              72      42  wood     seat (0,0.45,0), motor pivot (-1.7,0.4,0)
characters/enemies/raider.glb                            200     114  dirt     STATIC unrigged. Add AnimationPlayer in Godot. Idle/Walk/Run/Attack/Hit/Death not embedded.
characters/boss/brute_boss.glb                           200     114  metal    STATIC unrigged boss ~3.4m. Animate in Godot.

LICENSE: original generated content for Gray Card Wars. No third-party IPs.
Building pieces: foundation, triangle_foundation, wall, doorway_wall, door,
window_wall, window, half_wall, floor, roof, triangle_roof, stairs, ramp, pillar, fence.
Weapons are fictional scrap designs, not real-world firearms.